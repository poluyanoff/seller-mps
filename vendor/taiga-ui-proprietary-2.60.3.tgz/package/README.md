# Taiga UI · Т-Банк

Рабочая копия внутренней дизайн-системы Taiga UI Т-Банка, собранной с Claude из Figma-гайдов TUI Desktop и TUI Mobile.

Источник компонентов — артефакт «Taiga UI · Т-Банк» на claude.ai. В репозитории хранятся его файлы и сборка npm-пакета `taiga-ui-proprietary` для React 18.

- ДС: https://claude.ai/artifact/MAiHMdJEhMriL8XmESWnLQ
- Песочница: https://claude.ai/artifact/CWd9cxCsY8N1qT4F4sFUoM

## Главная страница

```sh
npm ci
npm run dev
```

Откройте адрес из терминала (по умолчанию [localhost:4173](http://127.0.0.1:4173/)). В корне открывается раздел «Начало работы» в layout playground: описание проекта, команды создания стартового шаблона, правила работы и проверка версий. Компоненты доступны по `/playground/`, история — по `/playground/changelog.html`. Welcome использует общую шапку и боковую навигацию playground. Прямые ссылки на компоненты сохраняются, например `/playground/#Button`.

## Состав
| Папка | Что внутри |
|---|---|
| `design-system/` | Файлы артефакта ДС: `README.md` (правила и токены), разделы (`*.md`), `tokens.json`, `design-system.json` (индекс), `assets/` (логотипы) |
| `design-system/components/` | Компоненты: `bundle.js` / `bundle.css` (React 18, глобальный `window.TaigaUI`), `index.d.ts` (типы), `illustrations.js`; в папке каждого компонента — `README.md` и `preview.html` |
| `playground/` | Песочница: живые примеры компонентов, редактор пропсов, лог событий |
| `src/` | Рабочие исходники последних компонентов до вклейки в бандл (PageHeader, NavigationBar, FilterTable, контролы, Dropdown, Dialog, BottomSheet, Select / Combobox) |
| `scripts/` | Сборка npm-пакета из бандла компонентов |
| `tests/` | Проверки экспортов, рендеринга, диалогов, типов и установки из архива |
| `dist/` | Результат сборки: ESM, CommonJS, типы, стили и токены; в Git не хранится |

## Разделы ДС
README · Токены · Личный кабинет: веб и PWA (`lk-web.md`) · Навигация · WebView · Шаблоны экранов · Ориджинейшен · Формы · Чекбоксы, радио, тогглы (`controls.md`) · Табличные листинги (`table-listings.md`) · Фильтры · Ошибки · Кастомные карточки · Affix / fade · AI.

## Компоненты
PageLayout, PageFooter, PageHeader, NavigationBar, DesktopAppBar, DetailsLayout, ServiceBar, InputFiles, InputDate, InputTime, ImageViewer, TabBar, Icon, Illustration, Group, List, Button, Link, ButtonVertical, Input, SearchBar, Cell (+ connected, варианты), Header, Avatar, AvatarStack, Badge, BadgedContent, Chip, ChipGroup, Checkbox, CheckboxGroup, Radio, RadioGroup, RadioBlock, CheckboxBlock (+ RadioBlockGroup, CheckboxBlockGroup), Calendar, CalendarDropdown, ProgressBar, ProgressCircle, Loader, Amount, Toggle / Switch, Dropdown / DropdownList, Tabs, Select, Combobox, Autocomplete, Textarea, InputChip, InputAmount, InputPhone, InputPassword, BlockStatus, BlockDetails, Segmented, NotificationBanner, Toast (showToast, ToastHost), Tooltip / TooltipHost, Dialog, BottomSheet, CardLarge, CardMedium, AvatarLabelled, Row, Table, FilterTable (FilterBuilder, FilterSelect, Pagination, ListingStatus), FloatingContainer, IllustrationScreen, OnboardingFlow.

Также: Panel (тёмная панель продукта или счёта), ThumbnailCard (миниатюра карты).
Также: ButtonGroupCard (карточка быстрых действий).
Также: ButtonTooltip (кнопка-подсказка «?» / «i»).
Также: NotificationPush (пуш-нотификация на десктопе) и NotificationFeed (лента пушей).
Также: ButtonClose (кнопка-крестик).
Также: MessageBubble (баббл комментария или сообщения).
Также: ChatMessage и ChatDivider (сообщение и разделители ленты чата).
Также: ChatInput и ChatHints (панель ввода и подсказки в чате).
Также: ChatCell (ячейка списка чатов).
Также: Timeline и TimelineItem (вертикальный таймлайн событий).
Также: ActionBar (бар массовых действий с выбранными элементами).
Также: ListCard и CardList (карточный вид списка).
Также: SmartFilter и KeyValueSelect (смартфильтр: поиск и фильтры в одной строке, выбор «ключ:значение»).
Также: PopoverCard и PopoverCardHost (всплывающая карточка с указателем: онбординг и подсказки о новых функциях).

## Стартовый проект одной командой

Нужны Node.js 20+, npm и Git. После получения репозитория выполните в его папке:

```sh
npm ci
npm run starter -- ../my-prototype            # десктоп
npm run starter -- ../my-prototype --mobile   # мобилка: iOS, рамка телефона 375
cd ../my-prototype
npm run dev
```

Генератор создаст отдельный проект, установит React 18, сборщик и текущую библиотеку из локального архива. Адрес страницы появится в терминале. Папка назначения должна быть пустой. Компоненты, стили, шрифты, тема `desktop-day` и проверка нарушений ДС уже подключены. Редактируйте `screens/main.js`; правила и описания компонентов лежат в `docs/`. Готовая сборка: `npm run build`.

**Проверка версии включена по умолчанию:** при запуске `npm run dev` и каждые 15 минут. Она читает версию из основной ветки закрытого Git-репозитория через доступы Git на компьютере пользователя. Результат выводится в терминал. При отсутствии сети или доступа проект работает, но проверка сообщает, что актуальность неизвестна. На статическом хостинге проверка не выполняется. Новые версии не устанавливаются автоматически.

В созданном проекте `npm run library:check` запускает проверку вручную. Адрес источника, ветку и интервал можно изменить в `library.config.json`. Для SSH укажите SSH-адрес репозитория. Токены в браузер не передаются; для HTTPS используйте Git credential helper.

Для обновления получите свежую библиотеку, соберите её через `npm pack`, скопируйте архив в `vendor/` проекта и выполните `npm install ./vendor/<новый-архив>.tgz`. Затем перезапустите сервер и сохраните архив вместе с `package.json` и `package-lock.json`.

Генератор также входит в npm-архив. Получателю архива не нужна локальная копия библиотеки:

```sh
npm exec --yes --package=/path/to/taiga-ui-proprietary-<версия>.tgz -- taiga-ui-create ./my-prototype
```

Параметры: `--no-install` — создать файлы без установки зависимостей; `--repository <URL или путь Git>` — другой источник проверки версии. Доступ к обычному npm-реестру нужен для React и сборщика; сама библиотека остаётся локальным архивом.

## Установка npm-пакета

Для сборки нужен Node.js 20 или новее. В папке этой библиотеки выполните:

```sh
npm ci
npm test
npm pack
```

Команда `npm pack` соберёт библиотеку и создаст `taiga-ui-proprietary-<версия>.tgz`. В новом проекте установите архив, указав путь к нему:

```sh
npm install /path/to/taiga-ui-proprietary-<версия>.tgz react@18.3.1 react-dom@18.3.1
```

В приложении подключите стили один раз и импортируйте компоненты:

```tsx
import { Button, CardLarge } from 'taiga-ui-proprietary';
import type { ButtonProps } from 'taiga-ui-proprietary';
import 'taiga-ui-proprietary/styles.css';

const buttonProps: ButtonProps = { appearance: 'primary', size: 'm' };

export function App() {
  return (
    <div data-theme="desktop-day">
      <CardLarge>
        <Button {...buttonProps} onClick={() => alert('Готово')}>
          Продолжить
        </Button>
      </CardLarge>
    </div>
  );
}
```

Для TypeScript установите в приложении `@types/react@18` и `@types/react-dom@18`. Тема задаётся через `data-theme`: `desktop-day/night`, `ios-day/night`, `android-day/night`. Шрифты и токены входят в стили, иконки и иллюстрации — в JavaScript. JSON токенов доступен по пути `taiga-ui-proprietary/tokens.json`.

React и ReactDOM используются из приложения и не встраиваются в пакет. Поддерживается React 18.3.1; React 19 пока не проверен. Доступны ESM (`import`) и CommonJS (`require`), глобальные `window.React` и `window.TaigaUI` для npm-подключения не нужны. Импорт пакета работает без браузерного DOM; интерактивные компоненты предназначены для браузера. Для Next.js компоненты собраны с директивой `use client`.

Пакет содержит общий модуль компонентов и набор графики. Упаковка в npm сама по себе не гарантирует минимальный размер сборки приложения.

Для локальной разработки можно после `npm ci` подключить папку библиотеки: `npm install ../taiga-ui-proprietary`. После изменений запускайте в библиотеке `npm run build`. Для передачи между проектами используйте архив: он фиксирует содержимое версии и не зависит от символических ссылок.

Пакет помечен `private: true`: локальная установка работает, публикация в реестр отключена. Реестр для распространения пока не настроен. Шрифты и ассеты сохраняют ограничения внутреннего использования.

## Подключение через HTML
```html
<link rel="stylesheet" href="design-system/components/bundle.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js"></script>
<script src="design-system/components/bundle.js"></script>
<body data-theme="desktop-day"> <!-- desktop-day/night, ios-day/night, android-day/night -->
```
Токены (`--tui-*`) лежат в стилях артефакта; в песочнице — `playground/tokens.css`.

## Прототипы на ДС (для продактов и нейросетей)

Демо-страницы и шаблоны Бухгалтерии перенесены в проект `accounting-2027`, папку `screens/`. Для прототипов других направлений — генератор, раздел «Стартовый проект одной командой». Запуск и добавление прототипов описаны в [README проекта](../accounting-2027/README.md#перенесённые-демо-страницы).

Этот репозиторий содержит библиотеку, документацию и playground. Прототипы используют установленный npm-пакет `taiga-ui-proprietary`; копировать бандлы библиотеки в проект не нужно.

## Шрифты
Шрифты встроены в `design-system/components/bundle.css` (`@font-face`, woff2 внутри), ставить их не нужно: T-Sans, Neue Haas Unica W1G, Roboto и Open Runde (цифры). Отдельные файлы — в `design-system/fonts/`. SF Pro не встроен (лицензия Apple): на Mac и iPhone он системный. T-Sans и Unica — по лицензии банка, только для внутренней работы.

## Известные пробелы
- Сетка S (824) для двухколоночного PageLayout, футер Т-Бизнеса.
- Пункты мобильного таб-бара Т-Бизнеса, pressed-состояние белого чипа, тексты пустых листингов, пагинация по страницам.
- Подробности — в разделах «Пробелы» в README компонентов.

## Как обновлять
Изменения вносятся в артефакт ДС, после чего его файлы копируются сюда отдельным коммитом с описанием изменений.

После обновления `design-system/components/bundle.js`, `bundle.css`, `index.d.ts`, `illustrations.js` или `design-system/tokens.json` запустите `npm test`. Скрипт сборки создаёт npm-модули из текущего бандла; файлы в `dist/` вручную не редактируются. Если формат бандла или состав API изменится без соответствующих типов, сборка сообщит об ошибке.

## Версии и история изменений

Текущая версия берётся из `package.json`. В шапке playground она показывается справа: `1.0.0` → `1.0`, `1.0.1` → `1.0.1`. Рядом находится ссылка на [историю изменений](playground/changelog.html). Источник записей — [CHANGELOG.md](CHANGELOG.md); этот файл также входит в npm-архив.

Чтобы подготовить следующую версию:

```sh
npm run release -- patch "Исправлено открытие Dialog при повторном нажатии."
npm test
npm pack
```

Вместо `patch` используйте `minor` для новых совместимых возможностей и `major` для несовместимых изменений. Можно передать несколько описаний отдельными аргументами. Команда обновляет `package.json` и `package-lock.json`, добавляет запись в `CHANGELOG.md` с датой по Москве и запускает сборку. Она готовит локальный выпуск; пакет в реестр не отправляется.

Перед упаковкой проверьте описание в `CHANGELOG.md`: оно должно отражать все итоговые изменения и при необходимости содержать инструкцию перехода на новый API. Правила для ИИ-агентов записаны в [AGENTS.md](AGENTS.md).

`npm run build` обновляет `playground/version.js` и `playground/changelog.html`, а также копирует канонические бандлы компонентов в playground. Страница истории статическая и открывается без сервера. Сгенерированные файлы включайте в коммит, чтобы версия и история были доступны сразу после получения репозитория.

Если номер пакета, lock-файла и последняя запись истории расходятся, сборка завершается с ошибкой. После подготовки версии установите новый архив в приложении. Подключение библиотеки через HTML сохранено.
