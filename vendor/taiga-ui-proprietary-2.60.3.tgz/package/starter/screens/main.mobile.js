import { React, createRoot, T } from './runtime.js';
const h = React.createElement;

/* Мобильный прототип: iOS, WebView, ширина 375 (design-system/README.md, «Размеры макетов»).
   Рамка телефона — обвязка прототипа, не компонент ДС: высота фиксированная, а не min-height,
   иначе кнопки внизу экрана прилипают к контенту. Статус-бар в прототипе показываем всегда. */
function Phone(props) {
  /* data-tui-portal и transform: шторки, диалоги и календарь открываются внутри рамки, а не на всё окно */
  return h('div', { 'data-tui-portal': '', style: { width: 375, height: 812, margin: '32px auto', overflow: 'hidden', position: 'relative', transform: 'translateZ(0)',
    borderRadius: 40, background: 'var(--tui-background-base)', boxShadow: '0 0 0 1px var(--tui-border-normal)' } },
    h('div', { style: { height: '100%', overflowY: 'auto' } }, props.children));
}

function App() {
  return h(Phone, null,
    h(T.PageLayout, { platform: 'mobile', header: { title: 'Главная' } },
      h(T.CardLarge, { platform: 'mobile', title: 'Соберите первый экран с ИИ-агентом',
        description: 'Опишите агенту, какой экран нужен и что на нем можно делать. Он соберет его из компонентов Taiga UI' },
        h('p', { className: 'tui-ios-body-s', style: { margin: 0 } }, 'Например: «Собери экран выписки по счету: баланс, кнопки пополнения и перевода, лента операций с фильтром»'))));
}

createRoot(document.getElementById('root')).render(h(App));
