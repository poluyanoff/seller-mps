import { React, createRoot, T } from './runtime.js';
import pkg from 'taiga-ui-proprietary/package.json';
const h = React.createElement;
function LibraryStatus() {
  const [info, setInfo] = React.useState({ status: 'checking', installed: pkg.version });
  const [busy, setBusy] = React.useState(false);
  const [message, setMessage] = React.useState('');
  async function check() {
    setBusy(true);
    try {
      const response = await fetch('/api/library', { cache: 'no-store' });
      if (!response.ok || !response.headers.get('content-type')?.includes('application/json')) throw new Error();
      setInfo(await response.json());
    } catch { setInfo({ status: 'unavailable', installed: pkg.version }); }
    finally { setBusy(false); }
  }
  React.useEffect(() => { void check(); const timer = setInterval(check, 900000); return () => clearInterval(timer); }, []);
  async function update() {
    setBusy(true);
    setMessage('Обновляем библиотеку. Это может занять несколько минут.');
    try {
      const response = await fetch('/api/library', { method: 'POST', headers: { 'X-Library-Action': 'install' } });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message);
      window.location.reload();
    } catch (error) { setMessage(error.message || 'Не получилось обновить библиотеку. Попробуйте снова'); setBusy(false); }
  }
  const statuses = {
    checking: 'Проверяем обновления…', current: 'Установлена актуальная версия.',
    ahead: 'Установленная версия новее версии в репозитории.',
    update: `Доступна версия ${info.latest}.`,
    unavailable: 'Не получилось проверить обновления. Проверьте сеть и доступ Git. На статическом сайте проверка недоступна.'
  };
  return h(T.CardLarge, { title: 'Библиотека компонентов', subtitle: `Taiga UI · ${info.installed || pkg.version}`,
    footer: h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: 16 } },
      info.status === 'update' && h(T.Button, { disabled: busy, loading: busy, onClick: update }, `Обновить до ${info.latest}`),
      h(T.Button, { appearance: 'secondary', disabled: busy, onClick: check }, 'Проверить обновления'))
  }, h('div', { 'aria-live': 'polite' }, h('p', { className: 'tui-body-m', style: { margin: 0 } }, statuses[info.status]),
    message && h('p', { className: 'tui-body-m' }, message)));
}
function App() {
  return h(T.PageLayout, {
    header: false, footer: false,
    layout: 'single',
    main: [h(T.CardLarge, { key: 'intro', title: 'Соберите первый экран с ИИ-агентом',
      description: 'Опишите агенту, какая страница нужна и что на ней можно делать. Он соберет ее из компонентов Taiga UI — формы, таблицы, личный кабинет и другие экраны.',
      footer: h(T.Link, { href: 'https://github.com/hsnvrsln/taiga-ui-tbank/tree/main/design-system/components', target: '_blank', rel: 'noopener noreferrer' }, 'Открыть библиотеку компонентов')
    }, h('p', { className: 'tui-body-m', style: { margin: 0 } }, 'Например: «Собери страницу счетов: список с суммами и статусами, фильтр по дате и кнопку создания счета».')),
      h(LibraryStatus, { key: 'library' })]
  });
}
createRoot(document.getElementById('root')).render(h('div', { style: { paddingTop: 32 } }, h(App)));
